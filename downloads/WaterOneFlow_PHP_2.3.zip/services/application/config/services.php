<?php defined('BASEPATH') OR exit('No direct script access allowed');
//Service code Settings
$config['auth_token'] = '';
$config['service_code'] = 'ODM';
$config['odm_service'] = 'http://his.cuahsi.org/ODMCV_1_1/ODMCV_1_1.asmx?wsdl';